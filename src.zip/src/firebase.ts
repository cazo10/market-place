import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  addDoc, 
  getDocs, 
  orderBy, 
  query, 
  doc, 
  getDoc, 
  updateDoc, 
  where,
  deleteDoc,
  onSnapshot,
  arrayUnion, 
  arrayRemove,
  setDoc,
  increment,
  serverTimestamp
} from 'firebase/firestore';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail
} from 'firebase/auth';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCpQ46RUY0_GHV5KhZVaI-RWGOtDUr18DY",
  authDomain: "ppdata2-5e1d9.firebaseapp.com",
  projectId: "ppdata2-5e1d9",
  storageBucket: "ppdata2-5e1d9.firebasestorage.app",
  messagingSenderId: "1035730649043",
  appId: "1:1035730649043:web:b75c8d8d1a2e38c5807926",
  measurementId: "G-8EQM8BKQ43"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

// Export all the functions you need
export { 
  doc, 
  getDoc, 
  setDoc, 
  addDoc, 
  collection, 
  updateDoc, 
  where, 
  orderBy, 
  query,
  getDocs,
  deleteDoc,
  onSnapshot,
  arrayUnion,
  arrayRemove,
  increment,
  serverTimestamp,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail
};