// src/types/menu.ts
export type MenuType = 'language' | 'user' | 'auth' | 'cart';